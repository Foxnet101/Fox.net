export interface Database {
  public: {
    Tables: {
      devices: {
        Row: {
          id: string;
          mac_address: string;
          ip_address: string;
          hostname: string | null;
          vendor: string | null;
          first_seen: string;
          last_seen: string;
          is_online: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          mac_address: string;
          ip_address: string;
          hostname?: string | null;
          vendor?: string | null;
          first_seen?: string;
          last_seen?: string;
          is_online?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          mac_address?: string;
          ip_address?: string;
          hostname?: string | null;
          vendor?: string | null;
          first_seen?: string;
          last_seen?: string;
          is_online?: boolean;
          created_at?: string;
        };
      };
      whitelist: {
        Row: {
          id: string;
          device_id: string | null;
          nickname: string;
          notes: string | null;
          added_at: string;
          added_by: string | null;
        };
        Insert: {
          id?: string;
          device_id?: string | null;
          nickname: string;
          notes?: string | null;
          added_at?: string;
          added_by?: string | null;
        };
        Update: {
          id?: string;
          device_id?: string | null;
          nickname?: string;
          notes?: string | null;
          added_at?: string;
          added_by?: string | null;
        };
      };
      dns_requests: {
        Row: {
          id: string;
          device_id: string | null;
          domain: string;
          ip_address: string | null;
          country: string | null;
          timestamp: string;
          request_type: string | null;
        };
        Insert: {
          id?: string;
          device_id?: string | null;
          domain: string;
          ip_address?: string | null;
          country?: string | null;
          timestamp?: string;
          request_type?: string | null;
        };
        Update: {
          id?: string;
          device_id?: string | null;
          domain?: string;
          ip_address?: string | null;
          country?: string | null;
          timestamp?: string;
          request_type?: string | null;
        };
      };
      alerts: {
        Row: {
          id: string;
          device_id: string | null;
          alert_type: string;
          message: string;
          severity: string | null;
          is_read: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          device_id?: string | null;
          alert_type: string;
          message: string;
          severity?: string | null;
          is_read?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          device_id?: string | null;
          alert_type?: string;
          message?: string;
          severity?: string | null;
          is_read?: boolean;
          created_at?: string;
        };
      };
    };
  };
}
