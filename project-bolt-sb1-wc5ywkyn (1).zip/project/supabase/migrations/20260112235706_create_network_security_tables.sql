/*
  # Network Security Monitoring Schema

  ## Overview
  Creates tables for network device monitoring, DNS tracking, and security alerting.

  ## New Tables
  
  ### `devices`
  Stores all discovered network devices
  - `id` (uuid, primary key) - Unique device identifier
  - `mac_address` (text, unique) - Device MAC address
  - `ip_address` (text) - Current IP address
  - `hostname` (text) - Device hostname
  - `vendor` (text) - Hardware vendor
  - `first_seen` (timestamptz) - First discovery time
  - `last_seen` (timestamptz) - Last seen online
  - `is_online` (boolean) - Current online status
  - `created_at` (timestamptz) - Record creation time

  ### `whitelist`
  Stores approved/known devices
  - `id` (uuid, primary key) - Unique identifier
  - `device_id` (uuid, foreign key) - Reference to device
  - `nickname` (text) - User-friendly name
  - `notes` (text) - Additional notes
  - `added_at` (timestamptz) - When added to whitelist
  - `added_by` (uuid) - User who added it

  ### `dns_requests`
  Logs DNS query activity
  - `id` (uuid, primary key) - Unique identifier
  - `device_id` (uuid, foreign key) - Device making request
  - `domain` (text) - Queried domain
  - `ip_address` (text) - Resolved IP
  - `country` (text) - Server country
  - `timestamp` (timestamptz) - Request time
  - `request_type` (text) - DNS record type

  ### `alerts`
  Security alerts and notifications
  - `id` (uuid, primary key) - Unique identifier
  - `device_id` (uuid, foreign key) - Related device
  - `alert_type` (text) - Type of alert
  - `message` (text) - Alert message
  - `severity` (text) - Alert severity level
  - `is_read` (boolean) - Read status
  - `created_at` (timestamptz) - Alert time

  ## Security
  - Enable RLS on all tables
  - Public read access for demo purposes (adjust for production)
  - Authenticated users can modify data
*/

-- Create devices table
CREATE TABLE IF NOT EXISTS devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mac_address text UNIQUE NOT NULL,
  ip_address text NOT NULL,
  hostname text,
  vendor text,
  first_seen timestamptz DEFAULT now(),
  last_seen timestamptz DEFAULT now(),
  is_online boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create whitelist table
CREATE TABLE IF NOT EXISTS whitelist (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id uuid REFERENCES devices(id) ON DELETE CASCADE,
  nickname text NOT NULL,
  notes text,
  added_at timestamptz DEFAULT now(),
  added_by uuid
);

-- Create dns_requests table
CREATE TABLE IF NOT EXISTS dns_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id uuid REFERENCES devices(id) ON DELETE CASCADE,
  domain text NOT NULL,
  ip_address text,
  country text,
  timestamp timestamptz DEFAULT now(),
  request_type text DEFAULT 'A'
);

-- Create alerts table
CREATE TABLE IF NOT EXISTS alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id uuid REFERENCES devices(id) ON DELETE CASCADE,
  alert_type text NOT NULL,
  message text NOT NULL,
  severity text DEFAULT 'medium',
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE whitelist ENABLE ROW LEVEL SECURITY;
ALTER TABLE dns_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;

-- Devices policies
CREATE POLICY "Anyone can view devices"
  ON devices FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert devices"
  ON devices FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update devices"
  ON devices FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete devices"
  ON devices FOR DELETE
  TO public
  USING (true);

-- Whitelist policies
CREATE POLICY "Anyone can view whitelist"
  ON whitelist FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert whitelist"
  ON whitelist FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update whitelist"
  ON whitelist FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete whitelist"
  ON whitelist FOR DELETE
  TO public
  USING (true);

-- DNS requests policies
CREATE POLICY "Anyone can view dns_requests"
  ON dns_requests FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert dns_requests"
  ON dns_requests FOR INSERT
  TO public
  WITH CHECK (true);

-- Alerts policies
CREATE POLICY "Anyone can view alerts"
  ON alerts FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert alerts"
  ON alerts FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update alerts"
  ON alerts FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete alerts"
  ON alerts FOR DELETE
  TO public
  USING (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_devices_mac ON devices(mac_address);
CREATE INDEX IF NOT EXISTS idx_devices_online ON devices(is_online);
CREATE INDEX IF NOT EXISTS idx_dns_timestamp ON dns_requests(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_alerts_unread ON alerts(is_read, created_at DESC);