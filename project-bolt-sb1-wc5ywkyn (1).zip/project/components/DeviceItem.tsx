import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Smartphone, Monitor, Wifi, Shield, ShieldAlert } from 'lucide-react-native';

interface DeviceItemProps {
  device: {
    id: string;
    hostname: string | null;
    ip_address: string;
    mac_address: string;
    vendor: string | null;
    is_online: boolean;
    last_seen: string;
  };
  isWhitelisted: boolean;
  onPress: () => void;
}

export function DeviceItem({ device, isWhitelisted, onPress }: DeviceItemProps) {
  const getDeviceIcon = () => {
    const vendor = device.vendor?.toLowerCase() || '';
    if (vendor.includes('apple') || vendor.includes('samsung')) {
      return <Smartphone size={20} color="#3b82f6" />;
    }
    return <Monitor size={20} color="#3b82f6" />;
  };

  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.content}>
        <View style={styles.iconContainer}>{getDeviceIcon()}</View>
        <View style={styles.info}>
          <View style={styles.row}>
            <Text style={styles.hostname}>
              {device.hostname || 'Unknown Device'}
            </Text>
            {isWhitelisted ? (
              <Shield size={16} color="#22c55e" />
            ) : (
              <ShieldAlert size={16} color="#f59e0b" />
            )}
          </View>
          <Text style={styles.detail}>
            {device.ip_address} • {device.mac_address}
          </Text>
          {device.vendor && <Text style={styles.vendor}>{device.vendor}</Text>}
        </View>
        <View style={styles.statusContainer}>
          <View style={[styles.statusDot, device.is_online && styles.statusOnline]} />
          <Text style={styles.statusText}>{device.is_online ? 'Online' : 'Offline'}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#1e40af',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  info: {
    flex: 1,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  hostname: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f1f5f9',
  },
  detail: {
    fontSize: 13,
    color: '#94a3b8',
    marginBottom: 2,
  },
  vendor: {
    fontSize: 12,
    color: '#64748b',
  },
  statusContainer: {
    alignItems: 'center',
    gap: 4,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#475569',
  },
  statusOnline: {
    backgroundColor: '#22c55e',
  },
  statusText: {
    fontSize: 11,
    color: '#94a3b8',
    fontWeight: '500',
  },
});
