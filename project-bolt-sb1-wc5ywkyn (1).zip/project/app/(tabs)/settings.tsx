import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Platform } from 'react-native';
import { useState, useEffect } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { supabase } from '@/lib/supabase';
import {
  Download,
  FileCode,
  Trash2,
  Shield,
  Database,
  ChevronRight,
  Package,
} from 'lucide-react-native';

export default function Settings() {
  const [stats, setStats] = useState({
    devices: 0,
    whitelist: 0,
    dnsRequests: 0,
    alerts: 0,
  });

  const loadStats = async () => {
    const [devices, whitelist, dnsRequests, alerts] = await Promise.all([
      supabase.from('devices').select('*', { count: 'exact', head: true }),
      supabase.from('whitelist').select('*', { count: 'exact', head: true }),
      supabase.from('dns_requests').select('*', { count: 'exact', head: true }),
      supabase.from('alerts').select('*', { count: 'exact', head: true }),
    ]);

    setStats({
      devices: devices.count || 0,
      whitelist: whitelist.count || 0,
      dnsRequests: dnsRequests.count || 0,
      alerts: alerts.count || 0,
    });
  };

  const exportSourceCode = () => {
    if (Platform.OS === 'web') {
      const repoUrl = 'https://github.com/your-repo/network-security-app';
      window.open(repoUrl, '_blank');
    } else {
      Alert.alert(
        'Export Source Code',
        'The source code can be found at: https://github.com/your-repo/network-security-app',
        [{ text: 'OK' }]
      );
    }
  };

  const exportAPK = () => {
    Alert.alert(
      'Build APK',
      'To build an APK, use Expo EAS Build:\n\n1. Install EAS CLI: npm install -g eas-cli\n2. Configure EAS: eas build:configure\n3. Build APK: eas build --platform android\n\nFor more info: https://docs.expo.dev/build/setup/',
      [{ text: 'OK' }]
    );
  };

  const exportData = async () => {
    const [devices, whitelist, dnsRequests, alerts] = await Promise.all([
      supabase.from('devices').select('*'),
      supabase.from('whitelist').select('*'),
      supabase.from('dns_requests').select('*'),
      supabase.from('alerts').select('*'),
    ]);

    const data = {
      exported_at: new Date().toISOString(),
      devices: devices.data || [],
      whitelist: whitelist.data || [],
      dns_requests: dnsRequests.data || [],
      alerts: alerts.data || [],
    };

    const json = JSON.stringify(data, null, 2);

    if (Platform.OS === 'web') {
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `network-security-export-${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  const clearAllData = () => {
    Alert.alert(
      'Clear All Data',
      'This will permanently delete all devices, whitelist entries, DNS requests, and alerts. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: async () => {
            await Promise.all([
              supabase.from('alerts').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
              supabase.from('dns_requests').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
              supabase.from('whitelist').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
              supabase.from('devices').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
            ]);
            loadStats();
          },
        },
      ]
    );
  };

  useEffect(() => {
    loadStats();
  }, []);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.title}>Settings</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Export</Text>

          <TouchableOpacity style={styles.menuItem} onPress={exportSourceCode}>
            <View style={styles.menuIcon}>
              <FileCode size={20} color="#3b82f6" />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuText}>Export Source Code</Text>
              <Text style={styles.menuSubtext}>Download the full app source code</Text>
            </View>
            <ChevronRight size={20} color="#64748b" />
          </TouchableOpacity>

          <TouchableOpacity style={styles.menuItem} onPress={exportAPK}>
            <View style={styles.menuIcon}>
              <Package size={20} color="#3b82f6" />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuText}>Build APK</Text>
              <Text style={styles.menuSubtext}>Instructions for building Android APK</Text>
            </View>
            <ChevronRight size={20} color="#64748b" />
          </TouchableOpacity>

          <TouchableOpacity style={styles.menuItem} onPress={exportData}>
            <View style={styles.menuIcon}>
              <Download size={20} color="#3b82f6" />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuText}>Export Data</Text>
              <Text style={styles.menuSubtext}>Download all security data as JSON</Text>
            </View>
            <ChevronRight size={20} color="#64748b" />
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Database</Text>

          <View style={styles.statsCard}>
            <View style={styles.statRow}>
              <Text style={styles.statLabel}>Devices</Text>
              <Text style={styles.statValue}>{stats.devices}</Text>
            </View>
            <View style={styles.statRow}>
              <Text style={styles.statLabel}>Whitelist Entries</Text>
              <Text style={styles.statValue}>{stats.whitelist}</Text>
            </View>
            <View style={styles.statRow}>
              <Text style={styles.statLabel}>DNS Requests</Text>
              <Text style={styles.statValue}>{stats.dnsRequests}</Text>
            </View>
            <View style={styles.statRow}>
              <Text style={styles.statLabel}>Alerts</Text>
              <Text style={styles.statValue}>{stats.alerts}</Text>
            </View>
          </View>

          <TouchableOpacity style={styles.dangerButton} onPress={clearAllData}>
            <Trash2 size={18} color="#ef4444" />
            <Text style={styles.dangerButtonText}>Clear All Data</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>

          <View style={styles.infoCard}>
            <Shield size={32} color="#3b82f6" />
            <Text style={styles.infoTitle}>Network Security Monitor</Text>
            <Text style={styles.infoText}>Version 1.0.0</Text>
            <Text style={styles.infoDescription}>
              Professional network monitoring and security dashboard for detecting and
              managing network devices, monitoring DNS traffic, and alerting on potential
              security threats.
            </Text>
          </View>

          <View style={styles.disclaimer}>
            <Text style={styles.disclaimerTitle}>Implementation Notes</Text>
            <Text style={styles.disclaimerText}>
              • ARP scanning requires native network permissions{'\n'}
              • DNS monitoring requires network-level interception{'\n'}
              • This demo uses simulated data for demonstration{'\n'}
              • For production use, deploy with proper network access{'\n'}
              • Use on authorized networks only
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    paddingBottom: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#f1f5f9',
  },
  section: {
    padding: 20,
    paddingTop: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#f1f5f9',
    marginBottom: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  menuIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#1e40af',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  menuContent: {
    flex: 1,
  },
  menuText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f1f5f9',
    marginBottom: 2,
  },
  menuSubtext: {
    fontSize: 13,
    color: '#94a3b8',
  },
  statsCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 16,
  },
  statRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  statLabel: {
    fontSize: 14,
    color: '#94a3b8',
  },
  statValue: {
    fontSize: 14,
    color: '#f1f5f9',
    fontWeight: '600',
  },
  dangerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#7f1d1d',
    padding: 14,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#991b1b',
  },
  dangerButtonText: {
    color: '#ef4444',
    fontSize: 16,
    fontWeight: '600',
  },
  infoCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 16,
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#f1f5f9',
    marginTop: 12,
    marginBottom: 4,
  },
  infoText: {
    fontSize: 14,
    color: '#94a3b8',
    marginBottom: 12,
  },
  infoDescription: {
    fontSize: 13,
    color: '#94a3b8',
    textAlign: 'center',
    lineHeight: 20,
  },
  disclaimer: {
    backgroundColor: '#1e40af',
    borderRadius: 12,
    padding: 16,
  },
  disclaimerTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#bfdbfe',
    marginBottom: 8,
  },
  disclaimerText: {
    fontSize: 12,
    color: '#bfdbfe',
    lineHeight: 20,
  },
});
