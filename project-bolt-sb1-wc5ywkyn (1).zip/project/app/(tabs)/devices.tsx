import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  ActivityIndicator,
} from 'react-native';
import { useState, useEffect } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { DeviceItem } from '@/components/DeviceItem';
import { supabase } from '@/lib/supabase';
import { Scan, Plus, X, Shield } from 'lucide-react-native';

export default function Devices() {
  const [devices, setDevices] = useState<any[]>([]);
  const [whitelistIds, setWhitelistIds] = useState<Set<string>>(new Set());
  const [scanning, setScanning] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<any>(null);
  const [newDevice, setNewDevice] = useState({
    hostname: '',
    ip_address: '',
    mac_address: '',
    vendor: '',
  });

  const loadDevices = async () => {
    const [devicesResult, whitelistResult] = await Promise.all([
      supabase.from('devices').select('*').order('last_seen', { ascending: false }),
      supabase.from('whitelist').select('device_id'),
    ]);

    if (devicesResult.data) {
      setDevices(devicesResult.data);
    }

    if (whitelistResult.data) {
      const ids = new Set(whitelistResult.data.map((w) => w.device_id).filter(Boolean));
      setWhitelistIds(ids);
    }
  };

  const simulateScan = async () => {
    setScanning(true);

    const mockDevices = [
      {
        hostname: 'iPhone-14-Pro',
        ip_address: '192.168.1.101',
        mac_address: '00:1A:2B:3C:4D:5E',
        vendor: 'Apple Inc.',
        is_online: true,
      },
      {
        hostname: 'Samsung-Galaxy',
        ip_address: '192.168.1.102',
        mac_address: '00:1A:2B:3C:4D:5F',
        vendor: 'Samsung Electronics',
        is_online: true,
      },
      {
        hostname: 'MacBook-Pro',
        ip_address: '192.168.1.103',
        mac_address: '00:1A:2B:3C:4D:60',
        vendor: 'Apple Inc.',
        is_online: true,
      },
    ];

    for (const device of mockDevices) {
      const { data: existing } = await supabase
        .from('devices')
        .select('*')
        .eq('mac_address', device.mac_address)
        .maybeSingle();

      if (!existing) {
        const { data: newDeviceData } = await supabase
          .from('devices')
          .insert(device)
          .select()
          .single();

        if (newDeviceData) {
          await supabase.from('alerts').insert({
            device_id: newDeviceData.id,
            alert_type: 'new_device',
            message: `New device detected: ${device.hostname || device.ip_address}`,
            severity: 'warning',
          });
        }
      } else {
        await supabase
          .from('devices')
          .update({ last_seen: new Date().toISOString(), is_online: true })
          .eq('id', existing.id);
      }
    }

    await loadDevices();
    setScanning(false);
  };

  const addManualDevice = async () => {
    if (!newDevice.ip_address || !newDevice.mac_address) {
      return;
    }

    await supabase.from('devices').insert({
      hostname: newDevice.hostname || null,
      ip_address: newDevice.ip_address,
      mac_address: newDevice.mac_address,
      vendor: newDevice.vendor || null,
      is_online: true,
    });

    setShowAddModal(false);
    setNewDevice({ hostname: '', ip_address: '', mac_address: '', vendor: '' });
    loadDevices();
  };

  const addToWhitelist = async (device: any) => {
    const { data } = await supabase
      .from('whitelist')
      .insert({
        device_id: device.id,
        nickname: device.hostname || device.ip_address,
        notes: `Added on ${new Date().toLocaleDateString()}`,
      })
      .select()
      .single();

    if (data) {
      setWhitelistIds(new Set([...whitelistIds, device.id]));
      await supabase.from('alerts').update({ is_read: true }).eq('device_id', device.id);
    }
    setSelectedDevice(null);
  };

  useEffect(() => {
    loadDevices();
  }, []);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Network Devices</Text>
        <View style={styles.actions}>
          <TouchableOpacity
            style={[styles.button, styles.scanButton]}
            onPress={simulateScan}
            disabled={scanning}>
            {scanning ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Scan size={18} color="#fff" />
            )}
            <Text style={styles.buttonText}>{scanning ? 'Scanning...' : 'Scan Network'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.addButton} onPress={() => setShowAddModal(true)}>
            <Plus size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.scrollView}>
        <View style={styles.notice}>
          <Text style={styles.noticeText}>
            Note: ARP scanning requires native network access. This demo uses simulated data.
            For real scanning, deploy on a device with network permissions.
          </Text>
        </View>

        <View style={styles.deviceList}>
          {devices.length === 0 ? (
            <View style={styles.emptyState}>
              <Scan size={40} color="#475569" />
              <Text style={styles.emptyText}>No devices found</Text>
              <Text style={styles.emptySubtext}>
                Tap Scan Network to discover devices
              </Text>
            </View>
          ) : (
            devices.map((device) => (
              <DeviceItem
                key={device.id}
                device={device}
                isWhitelisted={whitelistIds.has(device.id)}
                onPress={() => setSelectedDevice(device)}
              />
            ))
          )}
        </View>
      </ScrollView>

      <Modal visible={showAddModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Device Manually</Text>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <X size={24} color="#94a3b8" />
              </TouchableOpacity>
            </View>

            <TextInput
              style={styles.input}
              placeholder="Hostname (optional)"
              placeholderTextColor="#64748b"
              value={newDevice.hostname}
              onChangeText={(text) => setNewDevice({ ...newDevice, hostname: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="IP Address *"
              placeholderTextColor="#64748b"
              value={newDevice.ip_address}
              onChangeText={(text) => setNewDevice({ ...newDevice, ip_address: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="MAC Address *"
              placeholderTextColor="#64748b"
              value={newDevice.mac_address}
              onChangeText={(text) => setNewDevice({ ...newDevice, mac_address: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Vendor (optional)"
              placeholderTextColor="#64748b"
              value={newDevice.vendor}
              onChangeText={(text) => setNewDevice({ ...newDevice, vendor: text })}
            />

            <TouchableOpacity style={styles.addDeviceButton} onPress={addManualDevice}>
              <Text style={styles.addDeviceButtonText}>Add Device</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={selectedDevice !== null} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Device Details</Text>
              <TouchableOpacity onPress={() => setSelectedDevice(null)}>
                <X size={24} color="#94a3b8" />
              </TouchableOpacity>
            </View>

            {selectedDevice && (
              <>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Hostname</Text>
                  <Text style={styles.detailValue}>
                    {selectedDevice.hostname || 'Unknown'}
                  </Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>IP Address</Text>
                  <Text style={styles.detailValue}>{selectedDevice.ip_address}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>MAC Address</Text>
                  <Text style={styles.detailValue}>{selectedDevice.mac_address}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Vendor</Text>
                  <Text style={styles.detailValue}>{selectedDevice.vendor || 'Unknown'}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Status</Text>
                  <Text style={styles.detailValue}>
                    {selectedDevice.is_online ? 'Online' : 'Offline'}
                  </Text>
                </View>

                {!whitelistIds.has(selectedDevice.id) && (
                  <TouchableOpacity
                    style={styles.whitelistButton}
                    onPress={() => addToWhitelist(selectedDevice)}>
                    <Shield size={18} color="#fff" />
                    <Text style={styles.whitelistButtonText}>Add to Whitelist</Text>
                  </TouchableOpacity>
                )}
              </>
            )}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#f1f5f9',
  },
  actions: {
    flexDirection: 'row',
    gap: 8,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
  },
  scanButton: {
    backgroundColor: '#3b82f6',
  },
  addButton: {
    backgroundColor: '#3b82f6',
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  notice: {
    backgroundColor: '#1e40af',
    marginHorizontal: 20,
    marginBottom: 20,
    padding: 12,
    borderRadius: 8,
  },
  noticeText: {
    color: '#bfdbfe',
    fontSize: 12,
    lineHeight: 18,
  },
  deviceList: {
    padding: 20,
    paddingTop: 0,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: '#1e293b',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f1f5f9',
    marginTop: 12,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#94a3b8',
    marginTop: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#1e293b',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    borderWidth: 1,
    borderColor: '#334155',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#f1f5f9',
  },
  input: {
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    color: '#f1f5f9',
    fontSize: 14,
  },
  addDeviceButton: {
    backgroundColor: '#3b82f6',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  addDeviceButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  detailLabel: {
    fontSize: 14,
    color: '#94a3b8',
    fontWeight: '500',
  },
  detailValue: {
    fontSize: 14,
    color: '#f1f5f9',
    fontWeight: '600',
  },
  whitelistButton: {
    backgroundColor: '#22c55e',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 14,
    borderRadius: 8,
    marginTop: 20,
  },
  whitelistButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
