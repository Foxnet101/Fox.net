import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useState, useEffect } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { supabase } from '@/lib/supabase';
import { Globe, RefreshCw, TrendingUp } from 'lucide-react-native';

interface DnsRequest {
  id: string;
  domain: string;
  ip_address: string | null;
  country: string | null;
  timestamp: string;
  request_type: string | null;
}

export default function DnsMonitor() {
  const [requests, setRequests] = useState<DnsRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [countryStats, setCountryStats] = useState<Record<string, number>>({});

  const loadDnsRequests = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('dns_requests')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(50);

    if (data) {
      setRequests(data);

      const stats: Record<string, number> = {};
      data.forEach((req) => {
        if (req.country) {
          stats[req.country] = (stats[req.country] || 0) + 1;
        }
      });
      setCountryStats(stats);
    }
    setLoading(false);
  };

  const simulateTraffic = async () => {
    const mockRequests = [
      { domain: 'api.github.com', ip_address: '140.82.121.6', country: 'United States' },
      { domain: 'www.google.com', ip_address: '142.250.185.36', country: 'United States' },
      { domain: 'cdn.cloudflare.com', ip_address: '104.16.132.229', country: 'United States' },
      { domain: 'api.stripe.com', ip_address: '54.187.174.169', country: 'United States' },
      { domain: 'fonts.googleapis.com', ip_address: '142.250.185.42', country: 'United States' },
      { domain: 'api.openai.com', ip_address: '104.18.7.192', country: 'United States' },
      { domain: 'www.amazon.com', ip_address: '52.94.236.248', country: 'United States' },
      { domain: 'api.twitter.com', ip_address: '104.244.42.193', country: 'United States' },
      { domain: 'cdn.jsdelivr.net', ip_address: '151.101.1.229', country: 'Germany' },
      { domain: 'api.reddit.com', ip_address: '151.101.65.140', country: 'United States' },
    ];

    const { data: devices } = await supabase.from('devices').select('id').limit(1).single();

    for (const req of mockRequests.slice(0, 5)) {
      await supabase.from('dns_requests').insert({
        device_id: devices?.id || null,
        domain: req.domain,
        ip_address: req.ip_address,
        country: req.country,
        request_type: 'A',
      });
    }

    await loadDnsRequests();
  };

  useEffect(() => {
    loadDnsRequests();
  }, []);

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString();
  };

  const topCountries = Object.entries(countryStats)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>DNS Monitor</Text>
        <View style={styles.actions}>
          <TouchableOpacity
            style={styles.button}
            onPress={simulateTraffic}
            disabled={loading}>
            {loading ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <TrendingUp size={18} color="#fff" />
            )}
            <Text style={styles.buttonText}>Simulate</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.refreshButton} onPress={loadDnsRequests}>
            <RefreshCw size={18} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.scrollView}>
        <View style={styles.notice}>
          <Text style={styles.noticeText}>
            DNS interception requires network-level access. This demo shows simulated data.
            For real monitoring, set up DNS forwarding to your server or use a network gateway.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Top Countries</Text>
          <View style={styles.statsContainer}>
            {topCountries.length === 0 ? (
              <Text style={styles.noData}>No DNS data yet. Tap Simulate to generate traffic.</Text>
            ) : (
              topCountries.map(([country, count]) => (
                <View key={country} style={styles.statItem}>
                  <Globe size={16} color="#3b82f6" />
                  <Text style={styles.statCountry}>{country}</Text>
                  <Text style={styles.statCount}>{count} requests</Text>
                </View>
              ))
            )}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent DNS Requests</Text>
          {requests.length === 0 ? (
            <View style={styles.emptyState}>
              <Globe size={40} color="#475569" />
              <Text style={styles.emptyText}>No DNS requests logged</Text>
              <Text style={styles.emptySubtext}>
                DNS queries will appear here in real-time
              </Text>
            </View>
          ) : (
            requests.map((request) => (
              <View key={request.id} style={styles.requestItem}>
                <View style={styles.requestHeader}>
                  <Text style={styles.domain}>{request.domain}</Text>
                  <Text style={styles.time}>{formatTime(request.timestamp)}</Text>
                </View>
                <View style={styles.requestDetails}>
                  <Text style={styles.detail}>
                    {request.ip_address || 'Resolving...'}
                  </Text>
                  {request.country && (
                    <View style={styles.countryBadge}>
                      <Globe size={12} color="#3b82f6" />
                      <Text style={styles.countryText}>{request.country}</Text>
                    </View>
                  )}
                </View>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#f1f5f9',
  },
  actions: {
    flexDirection: 'row',
    gap: 8,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#3b82f6',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
  },
  refreshButton: {
    backgroundColor: '#3b82f6',
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  notice: {
    backgroundColor: '#1e40af',
    marginHorizontal: 20,
    marginBottom: 20,
    padding: 12,
    borderRadius: 8,
  },
  noticeText: {
    color: '#bfdbfe',
    fontSize: 12,
    lineHeight: 18,
  },
  section: {
    padding: 20,
    paddingTop: 0,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#f1f5f9',
    marginBottom: 16,
  },
  statsContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#334155',
    gap: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statCountry: {
    flex: 1,
    fontSize: 14,
    color: '#f1f5f9',
    fontWeight: '600',
  },
  statCount: {
    fontSize: 13,
    color: '#94a3b8',
  },
  noData: {
    fontSize: 14,
    color: '#94a3b8',
    textAlign: 'center',
  },
  requestItem: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  requestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  domain: {
    fontSize: 15,
    fontWeight: '600',
    color: '#f1f5f9',
    flex: 1,
  },
  time: {
    fontSize: 12,
    color: '#94a3b8',
  },
  requestDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  detail: {
    fontSize: 13,
    color: '#94a3b8',
    flex: 1,
  },
  countryBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#1e40af',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  countryText: {
    fontSize: 11,
    color: '#bfdbfe',
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: '#1e293b',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f1f5f9',
    marginTop: 12,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#94a3b8',
    marginTop: 4,
  },
});
