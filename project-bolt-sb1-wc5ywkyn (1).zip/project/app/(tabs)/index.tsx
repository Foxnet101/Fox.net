import { View, Text, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { useState, useEffect } from 'react';
import { StatsCard } from '@/components/StatsCard';
import { DeviceItem } from '@/components/DeviceItem';
import { supabase } from '@/lib/supabase';
import { Shield, Activity, AlertTriangle, Network } from 'lucide-react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function Dashboard() {
  const [stats, setStats] = useState({
    totalDevices: 0,
    onlineDevices: 0,
    whitelistedDevices: 0,
    activeAlerts: 0,
  });
  const [recentDevices, setRecentDevices] = useState<any[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [whitelistIds, setWhitelistIds] = useState<Set<string>>(new Set());

  const loadData = async () => {
    const [devicesResult, whitelistResult, alertsResult] = await Promise.all([
      supabase.from('devices').select('*').order('last_seen', { ascending: false }),
      supabase.from('whitelist').select('device_id'),
      supabase.from('alerts').select('*').eq('is_read', false),
    ]);

    if (devicesResult.data) {
      setStats((prev) => ({
        ...prev,
        totalDevices: devicesResult.data.length,
        onlineDevices: devicesResult.data.filter((d) => d.is_online).length,
      }));
      setRecentDevices(devicesResult.data.slice(0, 5));
    }

    if (whitelistResult.data) {
      const ids = new Set(whitelistResult.data.map((w) => w.device_id).filter(Boolean));
      setWhitelistIds(ids);
      setStats((prev) => ({
        ...prev,
        whitelistedDevices: whitelistResult.data.length,
      }));
    }

    if (alertsResult.data) {
      setStats((prev) => ({
        ...prev,
        activeAlerts: alertsResult.data.length,
      }));
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView
        style={styles.scrollView}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Network Security</Text>
            <Text style={styles.subtitle}>Real-time monitoring dashboard</Text>
          </View>
          <View style={styles.badge}>
            <Shield size={20} color="#22c55e" />
            <Text style={styles.badgeText}>Active</Text>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <StatsCard
            title="Total Devices"
            value={stats.totalDevices}
            icon={<Network size={18} color="#3b82f6" />}
          />
          <StatsCard
            title="Online Now"
            value={stats.onlineDevices}
            icon={<Activity size={18} color="#22c55e" />}
            trend={`${stats.onlineDevices} active`}
            trendPositive={true}
          />
          <StatsCard
            title="Whitelisted"
            value={stats.whitelistedDevices}
            icon={<Shield size={18} color="#3b82f6" />}
          />
          <StatsCard
            title="Alerts"
            value={stats.activeAlerts}
            icon={<AlertTriangle size={18} color="#f59e0b" />}
            trend={stats.activeAlerts > 0 ? 'Requires attention' : 'All clear'}
            trendPositive={stats.activeAlerts === 0}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Devices</Text>
          {recentDevices.length === 0 ? (
            <View style={styles.emptyState}>
              <Network size={40} color="#475569" />
              <Text style={styles.emptyText}>No devices detected</Text>
              <Text style={styles.emptySubtext}>
                Go to Devices tab to add or scan for devices
              </Text>
            </View>
          ) : (
            recentDevices.map((device) => (
              <DeviceItem
                key={device.id}
                device={device}
                isWhitelisted={whitelistIds.has(device.id)}
                onPress={() => {}}
              />
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#f1f5f9',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#94a3b8',
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#14532d',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  badgeText: {
    color: '#22c55e',
    fontSize: 13,
    fontWeight: '600',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 20,
    paddingTop: 0,
    gap: 12,
  },
  section: {
    padding: 20,
    paddingTop: 0,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#f1f5f9',
    marginBottom: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: '#1e293b',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f1f5f9',
    marginTop: 12,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#94a3b8',
    marginTop: 4,
    textAlign: 'center',
  },
});
